"use strict";
// Select all slides
const slides = document.querySelectorAll(".slide");

// Loop through slides and set each slide's translateX
slides.forEach((slide, indx) => {
  slide.style.transform = `translateX(${indx * 100}%)`;
});

// Current slide counter
let curSlide = 0;
// Maximum number of slides
let maxSlide = slides.length - 1;

// Function to move to the next slide
const nextSlide = () => {
  // Check if current slide is the last and reset current slide
  if (curSlide === maxSlide) {
    curSlide = 0;
  } else {
    curSlide++;
  }

  // Move slides by -100%
  slides.forEach((slide, indx) => {
    slide.style.transform = `translateX(${100 * (indx - curSlide)}%)`;
  });
};

// Function to move to the previous slide
const prevSlide = () => {
  // Check if current slide is the first and reset current slide to last
  if (curSlide === 0) {
    curSlide = maxSlide;
  } else {
    curSlide--;
  }

  // Move slides by 100%
  slides.forEach((slide, indx) => {
    slide.style.transform = `translateX(${100 * (indx - curSlide)}%)`;
  });
};

// Select next slide button
const nextBtn = document.querySelector(".btn-next");

// Add event listener to the next button
nextBtn.addEventListener("click", () => {
  nextSlide();
});

// Select previous slide button
const prevBtn = document.querySelector(".btn-prev");

// Add event listener to the previous button
prevBtn.addEventListener("click", () => {
  prevSlide();
});

// Auto-scroll to next slide every 5 seconds
setInterval(() => {
  nextSlide();
}, 5000);
